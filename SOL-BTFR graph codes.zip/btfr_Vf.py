#!/usr/bin/env python3
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

COLS = dict(
    name="galaxy",
    logMb="log10_Mb",
    elogMb="e_log10_Mb",
    Vf="Vf",
    eVf="e_Vf",
    Vmax="Vmax",
    eVmax="e_Vmax",
    V22="V2_2",
    eV22="e_V2_2",
    V2eff="V2eff",
    eV2eff="e_V2eff",
    Wm50c="Wm50c",
    eWm50c="e_Wm50c",
)

def _finite(df, cols):
    mask = np.ones(len(df), dtype=bool)
    for c in cols:
        if c in df.columns:
            mask &= np.isfinite(df[c].to_numpy(dtype=float))
    return df[mask]

def load_sparc_csv(path):
    df = pd.read_csv(path)
    keep_cols = [COLS["logMb"], COLS["Vf"], COLS["Vmax"], COLS["V22"], COLS["V2eff"], COLS["Wm50c"]]
    return _finite(df, [c for c in keep_cols if c in df.columns])

def xy_from(df, vcol):
    x = np.log10(df[vcol].to_numpy(dtype=float))
    y = df[COLS["logMb"]].to_numpy(dtype=float)
    return x, y

def fixed_slope_fit(x, y, b_fixed=4.0):
    a = float(np.mean(y - b_fixed * x))
    return a


import sys
df = load_sparc_csv(sys.argv[1])
ok = np.isfinite(df[COLS["Vf"]])
x, y = xy_from(df[ok], COLS["Vf"])
a = fixed_slope_fit(x, y, b_fixed=4.0)
plt.scatter(x, y, s=14, alpha=0.7)
plt.plot(x, a + 4*x, '--', label='SOL b=4')
plt.xlabel("log10 Vf")
plt.ylabel("log10 Mb")
plt.legend()
plt.savefig("btfr_Vf.png", dpi=200)
