#!/usr/bin/env python3
import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

rc = pd.read_csv(sys.argv[1])
r = rc["radius_kpc"].to_numpy(dtype=float)
v = rc["V_obs"].to_numpy(dtype=float)
if "e_V_obs" in rc.columns:
    ev = rc["e_V_obs"].to_numpy(dtype=float)
else:
    ev = None
Vflat = float(np.nanmedian(v[-5:] if len(v) > 5 else v))

if ev is not None:
    plt.errorbar(r, v, yerr=ev, fmt="o", ms=4, alpha=0.85, label="Observed")
else:
    plt.plot(r, v, "o", ms=4, alpha=0.85, label="Observed")
plt.axhline(Vflat, ls="--", lw=2, label=f"SOL asymptote ~ Vf ({Vflat:.1f} km/s)")
plt.xlabel("Radius (kpc)")
plt.ylabel("Velocity (km/s)")
plt.legend()
plt.savefig("sol_rotation_curve.png", dpi=200)
